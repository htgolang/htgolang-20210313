package context

import (
	"github.com/beego/beego/v2/server/web/context"
)

// Renderer defines an http response renderer
type Renderer context.Renderer
