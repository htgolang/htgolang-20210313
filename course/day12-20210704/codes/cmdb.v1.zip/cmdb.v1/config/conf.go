package config

var DbType = "mysql"
var DbDSN = "golang:golang@2021@tcp(10.0.0.2:3306)/cmdb?charset=utf8mb4&parseTime=true"

var ServerAddr = ":9999"
